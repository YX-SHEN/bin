#ifndef HALO_EXCHANGE_RMA_FENCE_H
#define HALO_EXCHANGE_RMA_FENCE_H

#include "poisson2d.h"
#include <mpi.h>

void exchange2d_rma_fence(double x[][maxn], int nx, int ny,
                          int sx, int ex, int sy, int ey,
                          MPI_Comm comm,
                          int nbrleft, int nbrright, int nbrbottom, int nbrtop,
                          MPI_Win win);

#endif

