#include <mpi.h>
#include "poisson2d.h"

/* fetch-only halo exchange using MPI_Win_fence
 *   x        : whole (maxn × maxn) array, row-major
 *   sx..ex   : local interior columns (global indices)
 *   sy..ey   : local interior rows    (global indices)
 *   nbr*     : Cartesian neighbours  (MPI_PROC_NULL if none)
 *   win      : window exposing the whole array
 */
void exchange2d_rma_fence(double x[][maxn], int nx, int ny,
                          int sx, int ex, int sy, int ey,
                          MPI_Comm comm,
                          int nbrleft, int nbrright,
                          int nbrbottom, int nbrtop,
                          MPI_Win win)
{
    /* 开始 RMA epoch */
    MPI_Win_fence(0, win);

    /* ---------- 左 / 右 ---------- */
    if (nbrleft != MPI_PROC_NULL) {
        for (int j = sy; j <= ey; j++) {
            /* 取左邻居最后一列 (全局列 = sx-1) */
            MPI_Get(&x[sx-1][j], 1, MPI_DOUBLE,
                    nbrleft,
                    (sx-1) * maxn + j, 1, MPI_DOUBLE,
                    win);
        }
    }

    if (nbrright != MPI_PROC_NULL) {
        for (int j = sy; j <= ey; j++) {
            /* 取右邻居第一列 (全局列 = ex+1) */
            MPI_Get(&x[ex+1][j], 1, MPI_DOUBLE,
                    nbrright,
                    (ex+1) * maxn + j, 1, MPI_DOUBLE,
                    win);
        }
    }

    /* ---------- 下 / 上 ---------- */
    if (nbrbottom != MPI_PROC_NULL) {
        for (int i = sx; i <= ex; i++) {
            /* 取底邻居最上一行 (全局行 = sy-1) */
            MPI_Get(&x[i][sy-1], 1, MPI_DOUBLE,
                    nbrbottom,
                    i * maxn + (sy-1), 1, MPI_DOUBLE,
                    win);
        }
    }

    if (nbrtop != MPI_PROC_NULL) {
        for (int i = sx; i <= ex; i++) {
            /* 取顶邻居最下一行 (全局行 = ey+1) */
            MPI_Get(&x[i][ey+1], 1, MPI_DOUBLE,
                    nbrtop,
                    i * maxn + (ey+1), 1, MPI_DOUBLE,
                    win);
        }
    }

    /* 结束 RMA epoch，保证所有 Get 完成 */
    MPI_Win_fence(0, win);
}
