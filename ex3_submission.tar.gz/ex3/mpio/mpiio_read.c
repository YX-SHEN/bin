// mpiio_read.c
// ============
// Demonstration of MPI‐IO to read:
//   1) A 20×20 matrix stored in mat-d20-b5-p4.bin,
//      laid out as four 5×20 block columns.
//   2) A length‐20 vector stored in x-d20.txt.bin,
//      laid out as four blocks of length 5.
// Each of the four MPI ranks reads exactly one block.
//
// Build and run:
//   mpicc -g -Wall mpiio_read.c -o mpiio_read
//   mpirun -np 4 ./mpiio_read

#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#define NPROCS   4     // number of MPI ranks expected
#define BLOCK    5     // number of columns per block (matrix) or length per block (vector)

int main(int argc, char **argv) {
    MPI_Init(&argc, &argv);

    int rank, nprocs;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

    // Ensure we run with exactly NPROCS
    if (nprocs != NPROCS) {
        if (rank == 0) {
            fprintf(stderr,
                    "Error: this program requires %d MPI ranks\n",
                    NPROCS);
        }
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    // -----------------------------
    // Part 1: Read the 20×20 matrix
    // -----------------------------
    MPI_File fh_matrix;
    MPI_File_open(MPI_COMM_WORLD,
                  "mat-d20-b5-p4.bin",
                  MPI_MODE_RDONLY,
                  MPI_INFO_NULL,
                  &fh_matrix);

    // 1.1 Read the matrix dimension (an int at the file start)
    int N;
    MPI_File_read_at(fh_matrix,
                     0,            // offset = 0 bytes
                     &N,
                     1,
                     MPI_INT,
                     MPI_STATUS_IGNORE);
    // Expect N == 20
    if (rank == 0 && N != 20) {
        fprintf(stderr,
                "Warning: expected matrix dimension 20, got %d\n",
                N);
    }

    // 1.2 Compute file offset to the first double element
    MPI_Offset matrix_data_offset = sizeof(int);

    // 1.3 Each rank reads BLOCK columns of height N → BLOCK * N doubles
    int num_elements = BLOCK * N;

    // 1.4 Compute this rank’s starting byte in the double array
    MPI_Offset my_matrix_disp =
        matrix_data_offset
      + (MPI_Offset)rank * num_elements * sizeof(double);

    // 1.5 Set an MPI‐IO view so that this rank sees
    //     exactly num_elements doubles starting at my_matrix_disp
    MPI_File_set_view(fh_matrix,
                      my_matrix_disp,
                      MPI_DOUBLE,       // elementary type
                      MPI_DOUBLE,       // file type
                      "native",         // representation
                      MPI_INFO_NULL);

    // 1.6 Allocate buffer & collectively read all elements
    double *local_matrix = malloc(num_elements * sizeof(double));
    MPI_File_read_all(fh_matrix,
                      local_matrix,
                      num_elements,
                      MPI_DOUBLE,
                      MPI_STATUS_IGNORE);

    MPI_File_close(&fh_matrix);

    // ----------------------------
    // Part 2: Read the length-20 vector
    // ----------------------------
    MPI_File fh_vector;
    MPI_File_open(MPI_COMM_WORLD,
                  "x-d20.txt.bin",
                  MPI_MODE_RDONLY,
                  MPI_INFO_NULL,
                  &fh_vector);

    // 2.1 Read the vector length (an int at file start)
    int vec_len;
    MPI_File_read_at(fh_vector,
                     0,
                     &vec_len,
                     1,
                     MPI_INT,
                     MPI_STATUS_IGNORE);
    // Expect vec_len == 20
    if (rank == 0 && vec_len != 20) {
        fprintf(stderr,
                "Warning: expected vector length 20, got %d\n",
                vec_len);
    }

    // 2.2 Skip the int header, then each rank reads BLOCK doubles
    MPI_Offset vector_data_offset = sizeof(int)
                                 + (MPI_Offset)rank * BLOCK * sizeof(double);

    MPI_File_set_view(fh_vector,
                      vector_data_offset,
                      MPI_DOUBLE,
                      MPI_DOUBLE,
                      "native",
                      MPI_INFO_NULL);

    double local_vector[BLOCK];
    MPI_File_read_all(fh_vector,
                      local_vector,
                      BLOCK,
                      MPI_DOUBLE,
                      MPI_STATUS_IGNORE);

    MPI_File_close(&fh_vector);

    // -------------------------------------
    // Part 3: Print a small verification
    // -------------------------------------
    printf("[rank %d] Read matrix block of size %d×%d and vector of length %d\n",
           rank, N, BLOCK, BLOCK);
    // Print first few entries for quick check
    printf("  matrix[0..2]  = %f, %f, %f\n",
           local_matrix[0],
           local_matrix[1],
           local_matrix[2]);
    printf("  vector[0..4]  = %f, %f, %f, %f, %f\n",
           local_vector[0],
           local_vector[1],
           local_vector[2],
           local_vector[3],
           local_vector[4]);

    free(local_matrix);
    MPI_Finalize();
    return 0;
}
