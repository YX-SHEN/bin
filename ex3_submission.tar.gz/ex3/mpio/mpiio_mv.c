/***********************************************************************
 * mpiio_mv.c  (final, verified)
 * --------------------------------------------------------------------
 * Parallel matrix–vector product y = A x using MPI-IO.
 *
 * File formats
 * ------------
 * mat-d20-b5-p4.bin
 *   [int N=20]  followed by four block-columns of A.
 *   Each block-column is a contiguous 20×5 slab stored row-major:
 *     ┌─────5─────┐
 *     │25│25│25│25│  ← four 5×5 sub-blocks in file order
 *     └───────────┘  => 100 doubles, no gaps
 *
 * x-d20.txt.bin
 *   [int N=20]  followed by 20 doubles (row-major).
 *
 * Rank k (k=0..3) reads the k-th block-column (100 doubles) and
 * the k-th 5-element slice of x, computes its local contribution
 * and the result is reduced (sum) onto rank 0.
 *
 * Build:
 *   mpicc -g -Wall -O2 mpiio_mv.c -o mpiio_mv
 * Run:
 *   mpirun -np 4 ./mpiio_mv
 ***********************************************************************/
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

enum { N = 20, BLOCK = 5, NPROCS = 4 };

int main(int argc, char **argv)
{
    MPI_Init(&argc, &argv);

    int rank, nprocs;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
    if (nprocs != NPROCS) {
        if (rank == 0)
            fprintf(stderr, "Error: run with %d MPI ranks\n", NPROCS);
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    /**************** 1. Read my 20×5 block-column of A ****************/
    MPI_File fhA;
    MPI_File_open(MPI_COMM_WORLD, "mat-d20-b5-p4.bin",
                  MPI_MODE_RDONLY, MPI_INFO_NULL, &fhA);

    /* Header: single int (should be 20) */
    int dim;
    MPI_File_read_at(fhA, 0, &dim, 1, MPI_INT, MPI_STATUS_IGNORE);
    if (rank == 0 && dim != N)
        fprintf(stderr, "Warning: matrix dim %d (expected %d)\n", dim, N);

    /* --- Simple contiguous view: my block = 100 doubles --- */
    const MPI_Offset block_bytes = (MPI_Offset)(N * BLOCK) * sizeof(double); /* 100 doubles */
    MPI_Offset disp = sizeof(int) + rank * block_bytes;

    MPI_File_set_view(fhA, disp,
                      MPI_DOUBLE,        /* etype  */
                      MPI_DOUBLE,        /* filetype = contiguous 100 doubles */
                      "native", MPI_INFO_NULL);

    double *Ablock = (double *)malloc(N * BLOCK * sizeof(double)); /* 20×5 */
    MPI_File_read_all(fhA, Ablock, N * BLOCK, MPI_DOUBLE, MPI_STATUS_IGNORE);
    MPI_File_close(&fhA);

    /**************** 2. Read my 5-element segment of x ****************/
    MPI_File fhx;
    MPI_File_open(MPI_COMM_WORLD, "x-d20.txt.bin",
                  MPI_MODE_RDONLY, MPI_INFO_NULL, &fhx);

    int vlen;
    MPI_File_read_at(fhx, 0, &vlen, 1, MPI_INT, MPI_STATUS_IGNORE);
    if (rank == 0 && vlen != N)
        fprintf(stderr, "Warning: vector length %d (expected %d)\n", vlen, N);

    MPI_Offset vec_disp = sizeof(int) + rank * BLOCK * sizeof(double);
    MPI_File_set_view(fhx, vec_disp,
                      MPI_DOUBLE, MPI_DOUBLE, "native", MPI_INFO_NULL);

    double xseg[BLOCK];
    MPI_File_read_all(fhx, xseg, BLOCK, MPI_DOUBLE, MPI_STATUS_IGNORE);
    MPI_File_close(&fhx);

    /**************** 3. Local product y_local = Ablock · xseg *********/
    double y_local[N] = {0.0};
    for (int i = 0; i < N; ++i) {
        double s = 0.0;
        for (int j = 0; j < BLOCK; ++j)
            s += Ablock[i * BLOCK + j] * xseg[j];   /* row-major index */
        y_local[i] = s;
    }
    free(Ablock);

    /**************** 4. Reduce to rank 0 ******************************/
    double y[N];
    MPI_Reduce(y_local, y, N, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    /**************** 5. Output ****************************************/
    if (rank == 0) {
        puts("y = A x   (first 10 entries)");
        for (int i = 0; i < 10; ++i)
            printf("  y[%2d] = %6.3f\n", i, y[i]);

        FILE *fp = fopen("y.txt", "w");
        for (int i = 0; i < N; ++i)
            fprintf(fp, "%.15g\n", y[i]);
        fclose(fp);
        puts("Full result written to y.txt");
    }

    MPI_Finalize();
    return 0;
}
