/* -----------------------------------------------------------
 * halo_exchange_rma_gats.c   ―  General Active-Target RMA
 *     Works byte-identical to sendrecv / fence
 * ----------------------------------------------------------- */
#include <mpi.h>
#include "poisson2d.h"

/* make two one-off datatypes:
 *   vert_t : whole column  (j varies, contiguous)
 *   horiz_t: whole row     (i varies, stride = maxn)
 */
static void build_types(int sx,int ex,int sy,int ey,
                        MPI_Datatype *vert_t, MPI_Datatype *horiz_t)
{
    /* column : length = ey-sy+1 , contiguous */
    MPI_Type_contiguous(ey - sy + 1, MPI_DOUBLE, vert_t);
    MPI_Type_commit(vert_t);

    /* row : length = ex-sx+1 , stride = maxn */
    MPI_Type_vector(ex - sx + 1, 1, maxn, MPI_DOUBLE, horiz_t);
    MPI_Type_commit(horiz_t);
}

void exchange2d_rma_gats(double x[][maxn],
                         int nx,int ny,
                         int sx,int ex,int sy,int ey,
                         MPI_Comm comm,
                         int nbrleft,int nbrright,
                         int nbrbottom,int nbrtop,
                         MPI_Win win)
{
    /* ---------- make datatypes ---------- */
    MPI_Datatype vert_t, horiz_t;
    build_types(sx,ex,sy,ey,&vert_t,&horiz_t);

    /* ---------- build neighbour group ---------- */
    int ranks[4], n = 0;
    if (nbrleft   != MPI_PROC_NULL) ranks[n++] = nbrleft;
    if (nbrright  != MPI_PROC_NULL) ranks[n++] = nbrright;
    if (nbrbottom != MPI_PROC_NULL) ranks[n++] = nbrbottom;
    if (nbrtop    != MPI_PROC_NULL) ranks[n++] = nbrtop;

    MPI_Group world_g, neigh_g;
    MPI_Comm_group(comm,&world_g);
    MPI_Group_incl(world_g,n,ranks,&neigh_g);

    /* post / start epochs */
    MPI_Win_post (neigh_g,0,win);
    MPI_Win_start(neigh_g,0,win);

    /* ---------- left / right : use vert_t (column) ---------- */
    if (nbrleft != MPI_PROC_NULL) {
        /* left neighbour’s last interior column (global i = sx-1) */
        MPI_Get(&x[sx-1][sy], 1, vert_t,
                nbrleft, (sx-1)*maxn + sy, 1, vert_t, win);
    }
    if (nbrright != MPI_PROC_NULL) {
        /* right neighbour’s first interior column (global i = ex+1) */
        MPI_Get(&x[ex+1][sy], 1, vert_t,
                nbrright,(ex+1)*maxn + sy, 1, vert_t, win);
    }

    /* ---------- bottom / top : use horiz_t (row) ---------- */
    if (nbrbottom != MPI_PROC_NULL) {
        /* bottom neighbour’s top interior row (global j = sy-1) */
        MPI_Get(&x[sx][sy-1], 1, horiz_t,
                nbrbottom, sx*maxn + (sy-1), 1, horiz_t, win);
    }
    if (nbrtop != MPI_PROC_NULL) {
        /* top neighbour’s bottom interior row (global j = ey+1) */
        MPI_Get(&x[sx][ey+1], 1, horiz_t,
                nbrtop,    sx*maxn + (ey+1), 1, horiz_t, win);
    }

    /* complete / wait */
    MPI_Win_complete(win);
    MPI_Win_wait   (win);

    /* free stuff */
    MPI_Type_free(&vert_t);
    MPI_Type_free(&horiz_t);
    MPI_Group_free(&neigh_g);
    MPI_Group_free(&world_g);
}
/* ----------------------------------------------------------- */
