#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <math.h>
#include <mpi.h>
#include "poisson2d.h"
#include "jacobi2d.h"
#include "decomp2d.h"
#include "halo_exchange_rma_gats.h"

// Define max and min macros
#define max(a, b) ((a) > (b) ? (a) : (b))
#define min(a, b) ((a) < (b) ? (a) : (b))

#define maxit 2000 // Fixed 2000 iterations

/* Function prototypes */
void init_full_grid(double g[][maxn]);
void init_full_grids(double a[][maxn], double b[][maxn], double f[][maxn]);
void twod_init(double a[][maxn], double b[][maxn], double f[][maxn],
               int nx, int ny, int sx, int ex, int sy, int ey);
void print_full_grid(double x[][maxn]);
void print_in_order(double x[][maxn], MPI_Comm comm);
void print_grid_to_file(char *fname, double x[][maxn], int nx, int ny);
double compute_error(double u_numeric[][maxn], int nx, int ny, int sx, int ex, int sy, int ey);

int main(int argc, char **argv)
{
    double a[maxn][maxn], b[maxn][maxn], f[maxn][maxn];
    MPI_Win win_a, win_b;
    double gathered_grid[maxn][maxn];
    int nx, ny;
    int myid, nprocs;
    int nbrleft, nbrright, nbrbottom, nbrtop;
    int sx, ex, sy, ey;
    int it;
    double glob_diff;
    double ldiff;
    double t1, t2;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &myid);
    MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

    // Process command line arguments
    if (myid == 0)
    {
        if (argc > 2) {
            fprintf(stderr, "Usage: mpirun -np <nproc> %s <nx>\n", argv[0]);
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        nx = (argc >= 2) ? atoi(argv[1]) : 31;
        if (nx > maxn - 2)
        {
            fprintf(stderr, "Grid size too large (max: %d)\n", maxn - 2);
            exit(1);
        }
    }

    MPI_Bcast(&nx, 1, MPI_INT, 0, MPI_COMM_WORLD);
    ny = nx;

    if (myid == 0)
    {
        printf("Grid size: %d x %d\n", nx, ny);
printf("Using general active-target RMA communication via MPI_Win_start/complete\n");
    }

    init_full_grids(a, b, f);

    // Create Cartesian topology

    int dims[2] = {0, 0}, periods[2] = {0, 0};
    MPE_Compute2dDims(nprocs, nx, ny, dims);
    MPI_Comm cart_comm;
    MPI_Cart_create(MPI_COMM_WORLD, 2, dims, periods, 1, &cart_comm);
    MPI_Comm_rank(cart_comm, &myid);
    int coords[2];
    MPI_Cart_coords(cart_comm, myid, 2, coords);
    MPI_Cart_shift(cart_comm, 0, 1, &nbrleft, &nbrright);
    MPI_Cart_shift(cart_comm, 1, 1, &nbrbottom, &nbrtop);
    MPE_Decomp2d(nx, ny, dims, coords, &sx, &ex, &sy, &ey);

    printf("Rank %d: Coords = (%d,%d), Domain = [%d:%d, %d:%d], Neighbors = L:%d R:%d B:%d T:%d\n",
           myid, coords[0], coords[1], sx, ex, sy, ey, nbrleft, nbrright, nbrbottom, nbrtop);
    // Initialize grid with boundary conditions
    twod_init(a, b, f, nx, ny, sx, ex, sy, ey);
    MPI_Win_create(&(a[0][0]), maxn * maxn * sizeof(double), sizeof(double),
                   MPI_INFO_NULL, cart_comm, &win_a);

    MPI_Win_create(&(b[0][0]), maxn * maxn * sizeof(double), sizeof(double),
                   MPI_INFO_NULL, cart_comm, &win_b);

    MPI_Barrier(cart_comm);
    t1 = MPI_Wtime();

    if (myid == 0)
    {
        printf("\n======> Running with MPI_Win_gats (RMA, fixed 2000 iterations)\n\n");
    }

    // Main iteration loop
    glob_diff = 1000;
    for (it = 0; it < maxit; it++)
    { // Strictly run 2000 iterations
        // Perform halo exchange
        exchange2d_rma_gats(a, nx, ny, sx, ex, sy, ey, cart_comm,
                             nbrleft, nbrright, nbrbottom, nbrtop, win_a);

        sweep2d(a, f, nx, ny, sx, ex, sy, ey, b);

        exchange2d_rma_gats(b, nx, ny, sx, ex, sy, ey, cart_comm,
                             nbrleft, nbrright, nbrbottom, nbrtop, win_b);

        sweep2d(b, f, nx, ny, sx, ex, sy, ey, a);

        // Calculate residual
        ldiff = griddiff2d(a, b, nx, ny, sx, ex, sy, ey);
        MPI_Allreduce(&ldiff, &glob_diff, 1, MPI_DOUBLE, MPI_SUM, cart_comm);

        // Progress output
        if (myid == 0 && it % 100 == 0)
        { // Output every 100 iterations
            printf("(myid %d) iteration: %d, glob_diff: %le\n", myid, it, glob_diff);
        }
    } // End of 2000 iterations

    t2 = MPI_Wtime();

    if (myid == 0)
    {
        printf("DONE! (iterations: %d)\n", maxit);
        printf("Run took %.6lf s\n", t2 - t1);
    }

    /* Error calculation section */
    // Calculate local squared sum of errors
    double local_sqsum = compute_error(a, nx, ny, sx, ex, sy, ey);

    // Calculate number of internal points handled by this process
    int local_points = (min(ex, nx) - max(sx, 1) + 1); // X-direction points
    local_points *= (min(ey, ny) - max(sy, 1) + 1);    // Y-direction points

    // Global reduction
    double global_sqsum;
    int global_points;
    MPI_Reduce(&local_sqsum, &global_sqsum, 1, MPI_DOUBLE, MPI_SUM, 0, cart_comm);
    MPI_Reduce(&local_points, &global_points, 1, MPI_INT, MPI_SUM, 0, cart_comm);

    // Root process output
    if (myid == 0)
    {
        // Calculate normalized L2 error
        double l2_error = sqrt(global_sqsum / (double)global_points);

        printf("L2 squared error (sum): %.12le\n", global_sqsum);
        printf("Total internal points: %d\n", global_points);
        printf("Normalized L2 error: %.12le\n", l2_error);
    }

    // Gather and output results
    GatherGrid2D(a, nx, ny, sx, ex, sy, ey, gathered_grid, cart_comm);

    if (myid == 0)
    {
        write_grid2d(gathered_grid, nx, ny, 1, nx, 1, ny, 0, cart_comm, "q4_solution.txt");
        printf("Solution written to q4_solution.txt\n");

        // Boundary verification
        double h = 1.0 / (nx + 1);
        int mid_j = (int)(0.5 / h);
        int mid_i = (int)(0.5 / h);

        printf("\nBoundary verification:\n");
        printf("u(0,0.5) = %.6f (should be %.6f)\n",
               gathered_grid[0][mid_j], 0.5 / (1.0 + pow(0.5, 2)));
        printf("u(1,0.5) = %.6f (should be %.6f)\n",
               gathered_grid[nx + 1][mid_j], 0.5 / (4.0 + pow(0.5, 2)));
        printf("u(0.5,1) = %.6f (should be %.6f)\n",
               gathered_grid[mid_i][ny + 1], 1.0 / (pow(1.0 + 0.5, 2) + 1.0));
    }
    MPI_Win_free(&win_a);
    MPI_Win_free(&win_b);
    MPI_Finalize();
    return 0;
}

// Initializes grid with boundary conditions
void twod_init(double a[][maxn], double b[][maxn], double f[][maxn],
               int nx, int ny, int sx, int ex, int sy, int ey)
{
    int i, j;
    double h = 1.0 / (nx + 1);

    // Initialize all points (including ghost cells) to 0
    for (i = sx - 1; i <= ex + 1; i++)
    {
        for (j = sy - 1; j <= ey + 1; j++)
        {
            a[i][j] = 0.0;
            b[i][j] = 0.0;
            f[i][j] = 0.0;
        }
    }

    // Set boundary conditions based on physical coordinates

    // Bottom boundary (y=0): u(x,0) = 0
    if (sy == 0)
    { // Check if contains bottom boundary
        for (i = sx; i <= ex; i++)
        {
            a[i][0] = 0.0;
            b[i][0] = 0.0;
        }
    }

    // Top boundary (y=1): u(x,1) = 1/((1+x)^2 + 1)
    if (ey == ny)
    {
        for (i = sx; i <= ex; i++)
        {
            double x = i * h;
            double val = 1.0 / (pow(1.0 + x, 2) + 1.0);
            a[i][ny + 1] = val;
            b[i][ny + 1] = val;
        }
    }

    // Left boundary (x=0): u(0,y) = y/(1 + y^2)
    if (sx == 0)
    { // Check if contains left boundary
        for (j = sy; j <= ey; j++)
        {
            double y = j * h;
            double val = y / (1.0 + y * y);
            a[0][j] = val;
            b[0][j] = val;
        }
    }

    // Right boundary (x=1): u(1,y) = y/(4 + y^2)
    if (ex == nx)
    {
        for (j = sy; j <= ey; j++)
        {
            double y = j * h;
            double val = y / (4.0 + y * y);
            a[nx + 1][j] = val;
            b[nx + 1][j] = val;
        }
    }
}

void init_full_grid(double g[][maxn])
{
    int i, j;
    const double junkval = -5;

    for (i = 0; i < maxn; i++)
    {
        for (j = 0; j < maxn; j++)
        {
            g[i][j] = junkval;
        }
    }
}

void init_full_grids(double a[][maxn], double b[][maxn], double f[][maxn])
{
    int i, j;
    const double junkval = -5;

    for (i = 0; i < maxn; i++)
    {
        for (j = 0; j < maxn; j++)
        {
            a[i][j] = junkval;
            b[i][j] = junkval;
            f[i][j] = junkval;
        }
    }
}

void print_full_grid(double x[][maxn])
{
    int i, j;
    for (j = maxn - 1; j >= 0; j--)
    {
        for (i = 0; i < maxn; i++)
        {
            if (x[i][j] < 10000.0)
            {
                printf("|%2.6lf| ", x[i][j]);
            }
            else
            {
                printf("%9.2lf ", x[i][j]);
            }
        }
        printf("\n");
    }
}

void print_in_order(double x[][maxn], MPI_Comm comm)
{
    int myid, size;
    int i;

    MPI_Comm_rank(comm, &myid);
    MPI_Comm_size(comm, &size);
    MPI_Barrier(comm);
    printf("Attempting to print in order\n");
    sleep(1);
    MPI_Barrier(comm);

    for (i = 0; i < size; i++)
    {
        if (i == myid)
        {
            printf("proc %d\n", myid);
            print_full_grid(x);
        }
        fflush(stdout);
        usleep(500);
        MPI_Barrier(comm);
    }
}

void print_grid_to_file(char *fname, double x[][maxn], int nx, int ny)
{
    FILE *fp;
    int i, j;

    fp = fopen(fname, "w");
    if (!fp)
    {
        fprintf(stderr, "Error: can't open file %s\n", fname);
        exit(4);
    }

    for (j = ny + 1; j >= 0; j--)
    {
        for (i = 0; i < nx + 2; i++)
        {
            fprintf(fp, "%lf ", x[i][j]);
        }
        fprintf(fp, "\n");
    }
    fclose(fp);
}

double compute_error(double u_numeric[][maxn], int nx, int ny, int sx, int ex, int sy, int ey)
{
    double h = 1.0 / (nx + 1);
    double sum = 0.0;

    // Only calculate interior points (i,j from 1 to nx/ny)
    for (int i = max(sx, 1); i <= min(ex, nx); i++)
    { // i ∈ [1, nx]
        for (int j = max(sy, 1); j <= min(ey, ny); j++)
        { // j ∈ [1, ny]
            double x = i * h;
            double y = j * h;
            double exact = y / ((1.0 + x) * (1.0 + x) + y * y);
            double diff = u_numeric[i][j] - exact;
            sum += diff * diff;
        }
    }
    return sum;
}



